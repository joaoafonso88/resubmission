//Huffman Coding
#include <bits/stdc++.h>

using namespace std;
string s;
int n;
char ch[26];
string f[26];
int inc = 0;
struct MinNode {

	
	char data;


	unsigned weight;

	
	MinNode *leftnode, *rightnode;

	MinNode(char data, unsigned weight)

	{

		leftnode = rightnode = NULL;
		this->data = data;
		this->weight = weight;
	}
};


struct compareNodes {

	bool operator()(MinNode* lt, MinNode* rt)

	{
		return (lt->weight > rt->weight);
	}
};

void print(){
    string encode="";
    for(int i=0; i < s.length(); i++){
        for(int j=0;j<n;j++){
            if(s[i]==ch[j]){
                encode = encode + f[j];
                break;
                }
            }
        }
        cout<<"Huffman code of a given input is: "+encode;
      
    }
void printHuffmanCodes(struct MinNode* rootnode, string strng)
{

	if (!rootnode){
    
		return;
	}
		

	if (rootnode->data != '$'){
	   
		cout << rootnode->data << ": " << strng << "\n";
		 ch[inc] = rootnode->data;
	    f[inc] = strng;
	    ++inc;
	}


	printHuffmanCodes(rootnode->rightnode, strng + "0");
	printHuffmanCodes(rootnode->leftnode, strng + "1");
	
}


void compress(char data[], int weight[], int size)
{
	struct MinNode *leftnode, *rightnode, *top;

	
	priority_queue<MinNode*, vector<MinNode*>, compareNodes> minHeap;

	for (int i = 0; i < size; ++i)
		minHeap.push(new MinNode(data[i], weight[i]));

	
	while (minHeap.size() != 1) {

	
		
       
		rightnode = minHeap.top();
		minHeap.pop();
		
         leftnode = minHeap.top();
		minHeap.pop();
	
		top = new MinNode('$', rightnode->weight + leftnode->weight);

		top->leftnode = leftnode;
		top->rightnode = rightnode;

		minHeap.push(top);
	}

	
	printHuffmanCodes(minHeap.top(), "");
}


int main()
{
    
    cout<<"enter some characters \n";
    cin>>s;
    string st="";
  st = st + s[0];
  for(int i = 1; i < s.length(); i++){
      int count = 0;
      for(int j = 0; j < st.length(); j++){
          if(s[i]==st[j])
          count = count + 1;
          }
          if(count==0){
              st = st + s[i];
              }
      }

    n = st.length();
  
	char arr[n + 1];
	strcpy(arr, st.c_str());
	
   
	int weight[n + 1];
	  for(int k = 0; k < n; k++){
      weight[k]=count(s.begin(), s.end(), st[k]);
      }



	
    	compress(arr, weight, n);
    	print();


	return 0;
}



