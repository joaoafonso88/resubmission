﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace palindrome
{
    class Program
    {
        static void Main(string[] args)
        {
            String word="",revword=""; 
            Console.WriteLine("enter a text to find it is palindrome or not");
            String text = Console.ReadLine();
            text = text.ToLower();
            for (int i = 0; i < text.Length; i++)
            {
                if (text[i] == ' ' || text[i] == ',' || text[i] == '"' ||text[i]=='?'||text[i]=='!')
                {
                    continue;
                }
                word = word + text[i];
            }
            for (int j = word.Length - 1; j >= 0; j--)
            {
                revword = revword + word[j];
            }
            if (word.Equals(revword))
            {
                Console.WriteLine("it is palindrome");
            }
            else
            {
                Console.WriteLine("it is not palindrome");
            }
            Console.ReadKey();
        }
    }
}
